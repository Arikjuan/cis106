# Notes 1 

* What is ***Markdown?*** 
  * Markdown is a markup language that lets you write plain text documents with a few lightweight formatting options. It was created by John Gruber in 2004 to allow users to not worry about html tagging and was to be future proof as it works with plain text documents. The file extension it uses is .md. 

* What is ***Git?***
  * Git is a version control system hat runs on your machine. It allows you to track your changes, have a historical backup, it allows for team development, it is very flexible. You interact with it on your command line rather than in the cloud which is Github. 

* What is **Github?**
  * Github is hosted Git which allows for storage in the form of repos that you can clone and then alter on your local machine (your pc) then you can push changes to the repo on Github.

* What is **Slack?**
  * Slack is a cloud-based team communication application similar to Discord but is more used for workplaces and allows you to collaborate with your team in the form of sending files, tools, and workflows in one environment 